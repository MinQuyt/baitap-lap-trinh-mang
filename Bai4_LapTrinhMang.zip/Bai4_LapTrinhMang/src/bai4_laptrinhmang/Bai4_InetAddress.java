/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bai4_laptrinhmang;

import java.net.InetAddress;

public class Bai4_InetAddress {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
         //tao doi tuong inetaddress bang ten may chu
         InetAddress addByName = InetAddress.getByName("www.google.com");  
         //tao doi tuong inetAddress bang dia chi IP
          InetAddress addByIP = InetAddress.getByName("142.251.220.36");
          System.out.println("Addres By name:"+addByName);
          System.out.println("Addres By IP:"+addByIP);
        //su dung getter,setter de lay thong tin ve dia chi IP
        //lay ten may chu:
        InetAddress addByName1 = InetAddress.getByName("www.vnexpress.com");
        String hostname=addByName1.getHostName();
        System.out.println("Host name:"+hostname);
        //lay dia chi IP 
        String ip=addByName1.getHostAddress();
        System.out.println("Dia chi ip:"+ip);
        InetAddress addByName2 = InetAddress.getByName("www.vnexpress.com");
        boolean isIP4= addByName2 instanceof java.net.Inet4Address;
            System.out.println("co phai IPV4 khong? "+isIP4);
            InetAddress addByName3 = InetAddress.getByName("www.vnexpress.com");
        boolean isIP6= addByName3 instanceof java.net.Inet6Address;
            System.out.println("co phai IPV6 khong? "+isIP6);
        } catch (Exception e) {
        }
    }   
    
}
