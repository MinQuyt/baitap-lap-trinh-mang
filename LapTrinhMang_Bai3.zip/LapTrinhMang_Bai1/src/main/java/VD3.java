/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class VD3 {
    private int count=0;
    //phuong thuc đồng bộ hóa
    public synchronized void incerment(){
        count++;
    }
    public synchronized void decrement(){
        count-=2;
    }
    //phuong thuc 3 khong dong bo hoa
    public  int getCount(){
        return count;
    }
    public static void main(String[] args) {
        VD3 counter = new VD3();
        //tao cac luong dem tang va giam
        Thread incremThread = new Thread(()->{
            for (int i = 0; i < 1000; i++) {
                counter.incerment();
            }
    });
        Thread decremThread = new Thread(()->{
            for (int i = 0; i < 1000; i++) {
                counter.decrement();
            }
    });
    //khoi chay cac luong
    incremThread.start();
    decremThread.start();
        try {
            //cho doi cho den khi cac luong hoan thanh
            incremThread.join();
            decremThread.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        //in ra ket qua cuoi cung
        System.out.println("count cuoi cung:"+counter.getCount());
    }
}
