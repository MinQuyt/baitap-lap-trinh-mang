package bai5;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class viduClient {
public static void main(String[] args) {
	final String Server_address="localhost";
	final int PORT=12345;
	try {
		Socket socket = new Socket(Server_address,PORT);
		BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
		BufferedReader userInput= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("client da ket noi voi server");
		String UserInputLine="";
		while((UserInputLine=userInput.readLine())!=null) {
			out.println(UserInputLine);
			String responsive=in.readLine();
			System.out.println("server tra ve "+responsive);
		}
	} catch (Exception e) {
		// TODO: handle exception
	}
}
}
