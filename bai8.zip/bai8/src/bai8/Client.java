/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai8;

import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) throws Exception {
        Socket socket = new Socket("localhost", 1234);
        
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
        Student student = (Student) in.readObject();
        System.out.println("Name: " + student.name);
        System.out.println("Age: " + student.age);
        
        in.close();
        socket.close();
    }
}

