/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class VD5 {
    private final Object monitor = new Object();
    public void waitForSignal() throws InterruptedException{ 
        synchronized (monitor) {
            monitor.wait(); // tien trinh se treo cho den khi motify
            
        }
    }
    public void notifySignal(){
        synchronized (monitor) {
            monitor.notify();
        }
    }
}
