
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class VD2 {
    private int count=0;
    private Lock lc = new ReentrantLock();//tao khoa
    public void demTang(){
        lc.lock();//khoa cac tien trinh khac
        try {
            count++;//de thuc hien dem
        } catch (Exception e) {
        } finally {
            lc.unlock();// mo tien trinh khac
        }
    }
}
