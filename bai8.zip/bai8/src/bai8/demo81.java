package bai8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class demo81 {
    public static void main(String[] args) {
        Student student = new Student("Tran Minh Quy", 20);
        // Tuần tự hóa đối tượng và ghi vào file
        try {
            FileOutputStream fileOut = new FileOutputStream("student.txt");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(student);
            out.close();
            fileOut.close();
            System.out.println("Đã tuần tự hóa và ghi đối tượng vào file");
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Đọc đối tượng từ file đã được tuần tự hóa
        try {
            FileInputStream fileIn = new FileInputStream("student.txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            Student stdFromFile = (Student) in.readObject();
            in.close();
            fileIn.close();
            System.out.println("Đọc đối tượng từ file:");
            System.out.println("Name: " + stdFromFile.getName());
            System.out.println("Age: " + stdFromFile.getAge());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
