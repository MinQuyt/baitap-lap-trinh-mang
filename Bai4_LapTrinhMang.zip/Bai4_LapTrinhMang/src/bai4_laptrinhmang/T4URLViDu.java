/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai4_laptrinhmang;

import java.net.URL;

/**
 *
 * @author Admin
 */
public class T4URLViDu {
    public static void main(String[] args) {
        try {
            URL url =new URL("https://fpl1.poly.edu.vn/ilias.php?lang=en&cmd=post&cmdClass=ilstartupgui&cmdNode=af&baseClass=ilStartUpGUI&rtoken=)");
            //phan tich thong tin tu URL
            System.out.println("protocol "+url.getProtocol());
            System.out.println("Host "+url.getHost());
            System.out.println("Port "+url.getPort());
            System.out.println("Path "+url.getPath());
            System.out.println("Truy van "+url.getQuery());
           System.out.println("Tham chieu "+url.getRef());
        } catch (Exception e) {
        }
    }
}
