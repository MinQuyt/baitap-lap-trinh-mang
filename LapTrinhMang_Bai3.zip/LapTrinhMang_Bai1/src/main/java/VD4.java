/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class VD4 {
    private final Object lc= new Object();
    //phuomg thuc duoc dong bo
    public  synchronized void phuongThuc1(){
        
    }
public  synchronized void phuongThuc2(){
        synchronized (lc) {
        
    }
    } 
    public static void main(String[] args) {
        Thread thread = new Thread(()->{
            
        });
        thread.start();//bat dau tien trinh
        try {
            thread.join();//cho cho tien trinh khac hoan thanh moi thuc hien
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
