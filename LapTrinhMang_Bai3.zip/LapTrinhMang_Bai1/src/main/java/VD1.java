/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class VD1 {
    //Sử dụng synchronize để đồng bộ hóa
    private int count=0;
    public  synchronized void demTang(){
        count++; // hàm đếm tăng có thể đồng bộ luồng
    }
}
