/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class VD6 {
    private final Object monitor = new Object();
    private boolean isDataReady=false;
    //ham san xuat du lieu
    public void productData() throws InterruptedException{
        synchronized (monitor) {
            //dam bao chi co 1 tien trinh duoc thuc hien
            while(isDataReady){
                monitor.wait();
            }
        
        //lap lại viec san xuat du lieu
        System.out.println("San xuat du lieu....");
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                e.printStackTrace();
            }

        //sau khi san xuat du lieu xong-> danh dau da san sang
        isDataReady=true;//thong bao cho tien trinh dang cho
        monitor.notify();   
        }
    }
    //ham su dung du lieu
    public void useData() throws InterruptedException{
        synchronized (monitor) {
            //dam bao cho co 1 tien trinh duoc thuc hien
            //neu du lieu da san sang thi tien trinh useData se thuc hien
            while(!isDataReady){
                monitor.wait();
            }
        
            //neu da sna sang thi su dung du lieu
            System.out.println("su dung du lieu");
            Thread.sleep(1000);
            //sau khi su dung xong thi danh dau
            isDataReady=false;
            //thong bao cho tien trinh đang co
            monitor.notify();
         }
    }
    public static void main(String[] args) {
        VD6 ex = new VD6();
        Thread thSanXuat=new Thread(()->{
            try {     
            while(true){
                ex.productData();
            }
        } catch (Exception e) {
        e.printStackTrace();
        } 
        });
       Thread thSuDung=new Thread(()->{
            try {     
            while(true){
                ex.useData();
            }
        } catch (Exception e) {
        e.printStackTrace();
        } 
        });
       //start
       thSanXuat.start();
       thSuDung.start();
    }
}