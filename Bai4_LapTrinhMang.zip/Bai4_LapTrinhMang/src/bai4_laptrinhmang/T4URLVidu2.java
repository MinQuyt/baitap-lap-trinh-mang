/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai4_laptrinhmang;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

/**
 *
 * @author Admin
 */
public class T4URLVidu2 {
    public static void main(String[] args) {
        try {
            //taodoi tuong tu dia chi URL
            URL url=new URL("https://www.google.com");
            URLConnection uRLConnection = url.openConnection();
            BufferedReader reader=new BufferedReader(new InputStreamReader(uRLConnection.getInputStream()));
            //tao doi tuong ghi file
            FileWriter fileWriter=new FileWriter("output.html");
            //doc tung dong 
            String line="";
            while((line=reader.readLine())!=null){
            //ghi vao file
            fileWriter.write(line+"\n");
        }
           //dong luong
           reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
